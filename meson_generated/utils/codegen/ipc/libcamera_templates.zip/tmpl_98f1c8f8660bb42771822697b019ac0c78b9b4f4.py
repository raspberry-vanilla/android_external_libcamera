from jinja2.runtime import LoopContext, Macro, Markup, Namespace, TemplateNotFound, TemplateReference, TemplateRuntimeError, Undefined, escape, identity, internalcode, markup_join, missing, str_join
name = 'module_ipa_serializer.h.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    concat = environment.concat
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_module_name = resolve('module_name')
    l_0_structs_nonempty = resolve('structs_nonempty')
    l_0_serializer = missing
    try:
        t_1 = environment.filters['name_full']
    except KeyError:
        @internalcode
        def t_1(*unused):
            raise TemplateRuntimeError("No filter named 'name_full' found.")
    pass
    l_0_serializer = context.vars['serializer'] = environment.get_template('serializer.tmpl', 'module_ipa_serializer.h.tmpl')._get_default_module(context)
    context.exported_vars.discard('serializer')
    yield '/* SPDX-License-Identifier: LGPL-2.1-or-later */\n/*\n * Copyright (C) 2020, Google Inc.\n *\n * Image Processing Algorithm data serializer for '
    yield str((undefined(name='module_name') if l_0_module_name is missing else l_0_module_name))
    yield '\n *\n * This file is auto-generated. Do not edit.\n */\n\n#pragma once\n\n#include <tuple>\n#include <vector>\n\n#include <libcamera/ipa/'
    yield str((undefined(name='module_name') if l_0_module_name is missing else l_0_module_name))
    yield '_ipa_interface.h>\n#include <libcamera/ipa/core_ipa_serializer.h>\n\n#include "libcamera/internal/control_serializer.h"\n#include "libcamera/internal/ipa_data_serializer.h"\n\nnamespace libcamera {\n\nLOG_DECLARE_CATEGORY(IPADataSerializer)\n'
    for l_1_struct in (undefined(name='structs_nonempty') if l_0_structs_nonempty is missing else l_0_structs_nonempty):
        _loop_vars = {}
        pass
        yield '\ntemplate<>\nclass IPADataSerializer<'
        yield str(t_1(l_1_struct))
        yield '>\n{\npublic:'
        yield str(context.call(environment.getattr((undefined(name='serializer') if l_0_serializer is missing else l_0_serializer), 'serializer'), l_1_struct, _loop_vars=_loop_vars))
        yield str(context.call(environment.getattr((undefined(name='serializer') if l_0_serializer is missing else l_0_serializer), 'deserializer'), l_1_struct, _loop_vars=_loop_vars))
        yield '\n};\n'
    l_1_struct = missing
    yield '\n\n} /* namespace libcamera */'

blocks = {}
debug_info = '5=20&11=23&21=25&30=27&32=31&35=33&36=34'