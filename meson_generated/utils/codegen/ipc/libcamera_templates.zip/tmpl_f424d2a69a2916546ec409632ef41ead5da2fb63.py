from jinja2.runtime import LoopContext, Macro, Markup, Namespace, TemplateNotFound, TemplateReference, TemplateRuntimeError, Undefined, escape, identity, internalcode, markup_join, missing, str_join
name = 'module_ipa_proxy.cpp.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    concat = environment.concat
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_module_name = resolve('module_name')
    l_0_has_namespace = resolve('has_namespace')
    l_0_namespace = resolve('namespace')
    l_0_proxy_name = resolve('proxy_name')
    l_0_interface_name = resolve('interface_name')
    l_0_interface_event = resolve('interface_event')
    l_0_interface_main = resolve('interface_main')
    l_0_cmd_enum_name = resolve('cmd_enum_name')
    l_0_cmd_event_enum_name = resolve('cmd_event_enum_name')
    l_0_proxy_funcs = missing
    try:
        t_1 = environment.filters['byte_width']
    except KeyError:
        @internalcode
        def t_1(*unused):
            raise TemplateRuntimeError("No filter named 'byte_width' found.")
    try:
        t_2 = environment.filters['cap']
    except KeyError:
        @internalcode
        def t_2(*unused):
            raise TemplateRuntimeError("No filter named 'cap' found.")
    try:
        t_3 = environment.filters['int']
    except KeyError:
        @internalcode
        def t_3(*unused):
            raise TemplateRuntimeError("No filter named 'int' found.")
    try:
        t_4 = environment.filters['is_async']
    except KeyError:
        @internalcode
        def t_4(*unused):
            raise TemplateRuntimeError("No filter named 'is_async' found.")
    try:
        t_5 = environment.filters['length']
    except KeyError:
        @internalcode
        def t_5(*unused):
            raise TemplateRuntimeError("No filter named 'length' found.")
    try:
        t_6 = environment.filters['method_param_inputs']
    except KeyError:
        @internalcode
        def t_6(*unused):
            raise TemplateRuntimeError("No filter named 'method_param_inputs' found.")
    try:
        t_7 = environment.filters['method_param_names']
    except KeyError:
        @internalcode
        def t_7(*unused):
            raise TemplateRuntimeError("No filter named 'method_param_names' found.")
    try:
        t_8 = environment.filters['method_param_outputs']
    except KeyError:
        @internalcode
        def t_8(*unused):
            raise TemplateRuntimeError("No filter named 'method_param_outputs' found.")
    try:
        t_9 = environment.filters['method_return_value']
    except KeyError:
        @internalcode
        def t_9(*unused):
            raise TemplateRuntimeError("No filter named 'method_return_value' found.")
    try:
        t_10 = environment.filters['params_comma_sep']
    except KeyError:
        @internalcode
        def t_10(*unused):
            raise TemplateRuntimeError("No filter named 'params_comma_sep' found.")
    try:
        t_11 = environment.filters['reverse']
    except KeyError:
        @internalcode
        def t_11(*unused):
            raise TemplateRuntimeError("No filter named 'reverse' found.")
    pass
    l_0_proxy_funcs = context.vars['proxy_funcs'] = environment.get_template('proxy_functions.tmpl', 'module_ipa_proxy.cpp.tmpl')._get_default_module(context)
    context.exported_vars.discard('proxy_funcs')
    yield '/* SPDX-License-Identifier: LGPL-2.1-or-later */\n/*\n * Copyright (C) 2020, Google Inc.\n *\n * Image Processing Algorithm proxy for '
    yield str((undefined(name='module_name') if l_0_module_name is missing else l_0_module_name))
    yield '\n *\n * This file is auto-generated. Do not edit.\n */\n\n#include <libcamera/ipa/'
    yield str((undefined(name='module_name') if l_0_module_name is missing else l_0_module_name))
    yield '_ipa_proxy.h>\n\n#include <memory>\n#include <string>\n#include <vector>\n\n#include <libcamera/ipa/ipa_module_info.h>\n#include <libcamera/ipa/'
    yield str((undefined(name='module_name') if l_0_module_name is missing else l_0_module_name))
    yield '_ipa_interface.h>\n#include <libcamera/ipa/'
    yield str((undefined(name='module_name') if l_0_module_name is missing else l_0_module_name))
    yield '_ipa_serializer.h>\n\n#include <libcamera/base/log.h>\n#include <libcamera/base/thread.h>\n\n#include "libcamera/internal/control_serializer.h"\n#include "libcamera/internal/ipa_data_serializer.h"\n#include "libcamera/internal/ipa_module.h"\n#include "libcamera/internal/ipa_proxy.h"\n#include "libcamera/internal/ipc_pipe.h"\n#include "libcamera/internal/ipc_pipe_unixsocket.h"\n#include "libcamera/internal/ipc_unixsocket.h"\n#include "libcamera/internal/process.h"\n\nnamespace libcamera {\n\nLOG_DECLARE_CATEGORY(IPAProxy)'
    if (undefined(name='has_namespace') if l_0_has_namespace is missing else l_0_has_namespace):
        pass
        yield '\n'
        for l_1_ns in (undefined(name='namespace') if l_0_namespace is missing else l_0_namespace):
            _loop_vars = {}
            pass
            yield '\nnamespace '
            yield str(l_1_ns)
            yield ' {\n'
        l_1_ns = missing
    yield '\n\n'
    yield str((undefined(name='proxy_name') if l_0_proxy_name is missing else l_0_proxy_name))
    yield 'Threaded::'
    yield str((undefined(name='proxy_name') if l_0_proxy_name is missing else l_0_proxy_name))
    yield 'Threaded(IPAModule *ipam, const GlobalConfiguration &configuration)\n\t: '
    yield str((undefined(name='proxy_name') if l_0_proxy_name is missing else l_0_proxy_name))
    yield '(ipam, configuration), thread_("'
    yield str((undefined(name='proxy_name') if l_0_proxy_name is missing else l_0_proxy_name))
    yield '")\n{\n\tLOG(IPAProxy, Debug)\n\t\t<< "initializing '
    yield str((undefined(name='module_name') if l_0_module_name is missing else l_0_module_name))
    yield ' proxy in thread: loading IPA from "\n\t\t<< ipam->path();\n\n\tif (!ipam->load())\n\t\treturn;\n\n\tIPAInterface *ipai = ipam->createInterface();\n\tif (!ipai) {\n\t\tLOG(IPAProxy, Error)\n\t\t\t<< "Failed to create IPA context for " << ipam->path();\n\t\treturn;\n\t}\n\n\tipa_ = std::unique_ptr<'
    yield str((undefined(name='interface_name') if l_0_interface_name is missing else l_0_interface_name))
    yield '>(static_cast<'
    yield str((undefined(name='interface_name') if l_0_interface_name is missing else l_0_interface_name))
    yield ' *>(ipai));\n\tproxy_.setIPA(ipa_.get());\n\n'
    for l_1_method in environment.getattr((undefined(name='interface_event') if l_0_interface_event is missing else l_0_interface_event), 'methods'):
        _loop_vars = {}
        pass
        yield '\n\tipa_->'
        yield str(environment.getattr(l_1_method, 'mojom_name'))
        yield '.connect(this, &'
        yield str((undefined(name='proxy_name') if l_0_proxy_name is missing else l_0_proxy_name))
        yield 'Threaded::'
        yield str(environment.getattr(l_1_method, 'mojom_name'))
        yield 'Handler);'
    l_1_method = missing
    yield '\n\n\tvalid_ = true;\n}\n\n'
    yield str((undefined(name='proxy_name') if l_0_proxy_name is missing else l_0_proxy_name))
    yield 'Threaded::~'
    yield str((undefined(name='proxy_name') if l_0_proxy_name is missing else l_0_proxy_name))
    yield 'Threaded() = default;\n\n'
    l_1_loop = missing
    for l_1_method, l_1_loop in LoopContext(environment.getattr((undefined(name='interface_main') if l_0_interface_main is missing else l_0_interface_main), 'methods'), undefined):
        _loop_vars = {}
        pass
        yield '\n'
        yield str(context.call(environment.getattr((undefined(name='proxy_funcs') if l_0_proxy_funcs is missing else l_0_proxy_funcs), 'func_sig'), ((undefined(name='proxy_name') if l_0_proxy_name is missing else l_0_proxy_name) + 'Threaded'), l_1_method, _loop_vars=_loop_vars))
        yield '\n{'
        if (environment.getattr(l_1_method, 'mojom_name') == 'stop'):
            pass
            yield '\n\t'
            yield str(context.call(environment.getattr((undefined(name='proxy_funcs') if l_0_proxy_funcs is missing else l_0_proxy_funcs), 'stop_thread_body'), _loop_vars=_loop_vars))
        elif (environment.getattr(l_1_method, 'mojom_name') == 'init'):
            pass
            yield '\n\t'
            yield str(((t_9(l_1_method) + ' _ret = ') if (t_9(l_1_method) != 'void') else cond_expr_undefined("the inline if-expression on line 83 in 'module_ipa_proxy.cpp.tmpl' evaluated to false and no else section was defined.")))
            yield 'ipa_->'
            yield str(environment.getattr(l_1_method, 'mojom_name'))
            yield '('
            l_2_loop = missing
            for l_2_param, l_2_loop in LoopContext(t_7(l_1_method), undefined):
                _loop_vars = {}
                pass
                yield str(l_2_param)
                yield str((', ' if (not environment.getattr(l_2_loop, 'last')) else cond_expr_undefined("the inline if-expression on line 86 in 'module_ipa_proxy.cpp.tmpl' evaluated to false and no else section was defined.")))
            l_2_loop = l_2_param = missing
            yield ');\n\n\tproxy_.moveToThread(&thread_);\n\n\treturn '
            yield str(('_ret' if (t_9(l_1_method) != 'void') else cond_expr_undefined("the inline if-expression on line 92 in 'module_ipa_proxy.cpp.tmpl' evaluated to false and no else section was defined.")))
            yield ';'
        elif (environment.getattr(l_1_method, 'mojom_name') == 'start'):
            pass
            yield '\n\tstate_ = ProxyRunning;\n\tthread_.start();\n\n\treturn proxy_.invokeMethod(&ThreadProxy::start, ConnectionTypeBlocking'
            yield str((', ' if t_7(l_1_method) else cond_expr_undefined("the inline if-expression on line 98 in 'module_ipa_proxy.cpp.tmpl' evaluated to false and no else section was defined.")))
            l_2_loop = missing
            for l_2_param, l_2_loop in LoopContext(t_7(l_1_method), undefined):
                _loop_vars = {}
                pass
                yield str(l_2_param)
                yield str((', ' if (not environment.getattr(l_2_loop, 'last')) else cond_expr_undefined("the inline if-expression on line 100 in 'module_ipa_proxy.cpp.tmpl' evaluated to false and no else section was defined.")))
            l_2_loop = l_2_param = missing
            yield ');'
        elif (not t_4(l_1_method)):
            pass
            yield '\n\treturn ipa_->'
            yield str(environment.getattr(l_1_method, 'mojom_name'))
            yield '('
            l_2_loop = missing
            for l_2_param, l_2_loop in LoopContext(t_7(l_1_method), undefined):
                _loop_vars = {}
                pass
                yield str(l_2_param)
                yield str((', ' if (not environment.getattr(l_2_loop, 'last')) else cond_expr_undefined("the inline if-expression on line 106 in 'module_ipa_proxy.cpp.tmpl' evaluated to false and no else section was defined.")))
            l_2_loop = l_2_param = missing
            yield ');\n'
        elif t_4(l_1_method):
            pass
            yield '\n\tASSERT(state_ == ProxyRunning);\n\tproxy_.invokeMethod(&ThreadProxy::'
            yield str(environment.getattr(l_1_method, 'mojom_name'))
            yield ', ConnectionTypeQueued'
            for l_2_param in t_7(l_1_method):
                _loop_vars = {}
                pass
                yield ', '
                yield str(l_2_param)
            l_2_param = missing
            yield ');'
        yield '\n}\n'
    l_1_loop = l_1_method = missing
    yield '\n\n'
    for l_1_method in environment.getattr((undefined(name='interface_event') if l_0_interface_event is missing else l_0_interface_event), 'methods'):
        _loop_vars = {}
        pass
        yield '\n'
        yield str(context.call(environment.getattr((undefined(name='proxy_funcs') if l_0_proxy_funcs is missing else l_0_proxy_funcs), 'func_sig'), ((undefined(name='proxy_name') if l_0_proxy_name is missing else l_0_proxy_name) + 'Threaded'), l_1_method, 'Handler', _loop_vars=_loop_vars))
        yield '\n{\n\tASSERT(state_ != ProxyStopped);\n\t'
        yield str(environment.getattr(l_1_method, 'mojom_name'))
        yield '.emit('
        yield str(t_10(environment.getattr(l_1_method, 'parameters')))
        yield ');\n}\n'
    l_1_method = missing
    yield '\n\n/* ========================================================================== */\n\n'
    yield str((undefined(name='proxy_name') if l_0_proxy_name is missing else l_0_proxy_name))
    yield 'Isolated::'
    yield str((undefined(name='proxy_name') if l_0_proxy_name is missing else l_0_proxy_name))
    yield 'Isolated(IPAModule *ipam, const GlobalConfiguration &configuration)\n\t: '
    yield str((undefined(name='proxy_name') if l_0_proxy_name is missing else l_0_proxy_name))
    yield '(ipam, configuration),\n\t  controlSerializer_(ControlSerializer::Role::Proxy), seq_(0)\n{\n\tLOG(IPAProxy, Debug)\n\t\t<< "initializing '
    yield str((undefined(name='module_name') if l_0_module_name is missing else l_0_module_name))
    yield ' proxy in isolation: loading IPA from "\n\t\t<< ipam->path();\n\n\tconst std::string proxyWorkerPath = resolvePath("'
    yield str((undefined(name='module_name') if l_0_module_name is missing else l_0_module_name))
    yield '_ipa_proxy");\n\tif (proxyWorkerPath.empty()) {\n\t\tLOG(IPAProxy, Error) << "Failed to get proxy worker path";\n\t\treturn;\n\t}\n\n\tauto ipc = std::make_unique<IPCPipeUnixSocket>(ipam->path().c_str(),\n\t\t\t\t\t\t       proxyWorkerPath.c_str());\n\tif (!ipc->isConnected()) {\n\t\tLOG(IPAProxy, Error) << "Failed to create IPCPipe";\n\t\treturn;\n\t}\n\n\tipc->recv.connect(this, &'
    yield str((undefined(name='proxy_name') if l_0_proxy_name is missing else l_0_proxy_name))
    yield 'Isolated::recvMessage);\n\n\tipc_ = std::move(ipc);\n\tvalid_ = true;\n}\n\n'
    yield str((undefined(name='proxy_name') if l_0_proxy_name is missing else l_0_proxy_name))
    yield 'Isolated::~'
    yield str((undefined(name='proxy_name') if l_0_proxy_name is missing else l_0_proxy_name))
    yield 'Isolated()\n{\n\tif (ipc_) {\n\t\tIPCMessage::Header header =\n\t\t\t{ static_cast<uint32_t>('
    yield str((undefined(name='cmd_enum_name') if l_0_cmd_enum_name is missing else l_0_cmd_enum_name))
    yield '::Exit), seq_++ };\n\t\tIPCMessage msg(header);\n\t\tipc_->sendAsync(msg);\n\t}\n}\n\n'
    for l_1_method in environment.getattr((undefined(name='interface_main') if l_0_interface_main is missing else l_0_interface_main), 'methods'):
        l_1_has_output = l_1_cmd = missing
        _loop_vars = {}
        pass
        yield '\n'
        yield str(context.call(environment.getattr((undefined(name='proxy_funcs') if l_0_proxy_funcs is missing else l_0_proxy_funcs), 'func_sig'), ((undefined(name='proxy_name') if l_0_proxy_name is missing else l_0_proxy_name) + 'Isolated'), l_1_method, _loop_vars=_loop_vars))
        yield '\n{'
        if (environment.getattr(l_1_method, 'mojom_name') == 'configure'):
            pass
            yield '\n\tcontrolSerializer_.reset();'
        l_1_has_output = (True if ((t_5(t_8(l_1_method)) > 0) or (t_9(l_1_method) != 'void')) else cond_expr_undefined("the inline if-expression on line 173 in 'module_ipa_proxy.cpp.tmpl' evaluated to false and no else section was defined."))
        _loop_vars['has_output'] = l_1_has_output
        l_1_cmd = (((undefined(name='cmd_enum_name') if l_0_cmd_enum_name is missing else l_0_cmd_enum_name) + '::') + t_2(environment.getattr(l_1_method, 'mojom_name')))
        _loop_vars['cmd'] = l_1_cmd
        yield '\n\tIPCMessage::Header _header = { static_cast<uint32_t>('
        yield str((undefined(name='cmd') if l_1_cmd is missing else l_1_cmd))
        yield '), seq_++ };\n\tIPCMessage _ipcInputBuf(_header);'
        if (undefined(name='has_output') if l_1_has_output is missing else l_1_has_output):
            pass
            yield '\n\tIPCMessage _ipcOutputBuf;'
        yield '\n\n'
        yield str(context.call(environment.getattr((undefined(name='proxy_funcs') if l_0_proxy_funcs is missing else l_0_proxy_funcs), 'serialize_call'), t_6(l_1_method), '_ipcInputBuf.data()', '_ipcInputBuf.fds()', _loop_vars=_loop_vars))
        yield '\n\n'
        if t_4(l_1_method):
            pass
            yield '\n\tint _ret = ipc_->sendAsync(_ipcInputBuf);'
        else:
            pass
            yield '\n\tint _ret = ipc_->sendSync(_ipcInputBuf'
            yield str((', &_ipcOutputBuf' if (undefined(name='has_output') if l_1_has_output is missing else l_1_has_output) else cond_expr_undefined("the inline if-expression on line 187 in 'module_ipa_proxy.cpp.tmpl' evaluated to false and no else section was defined.")))
            yield ');'
        yield '\n\tif (_ret < 0) {\n\t\tLOG(IPAProxy, Error) << "Failed to call '
        yield str(environment.getattr(l_1_method, 'mojom_name'))
        yield ': " << _ret;'
        if (t_9(l_1_method) != 'void'):
            pass
            yield '\n\t\treturn static_cast<'
            yield str(t_9(l_1_method))
            yield '>(_ret);'
        else:
            pass
            yield '\n\t\treturn;'
        yield '\n\t}\n'
        if (t_9(l_1_method) != 'void'):
            pass
            yield '\n\t'
            yield str(t_9(l_1_method))
            yield ' _retValue = IPADataSerializer<'
            yield str(t_9(l_1_method))
            yield '>::deserialize(_ipcOutputBuf.data(), 0);\n\n'
            yield str(context.call(environment.getattr((undefined(name='proxy_funcs') if l_0_proxy_funcs is missing else l_0_proxy_funcs), 'deserialize_call'), t_8(l_1_method), '_ipcOutputBuf.data()', '_ipcOutputBuf.fds()', init_offset=t_3(t_1(t_9(l_1_method))), _loop_vars=_loop_vars))
            yield '\n\n\treturn _retValue;\n\n'
        elif (t_5(t_8(l_1_method)) > 0):
            pass
            yield '\n'
            yield str(context.call(environment.getattr((undefined(name='proxy_funcs') if l_0_proxy_funcs is missing else l_0_proxy_funcs), 'deserialize_call'), t_8(l_1_method), '_ipcOutputBuf.data()', '_ipcOutputBuf.fds()', _loop_vars=_loop_vars))
            yield '\n'
        yield '}\n\n'
    l_1_method = l_1_has_output = l_1_cmd = missing
    yield '\n\nvoid '
    yield str((undefined(name='proxy_name') if l_0_proxy_name is missing else l_0_proxy_name))
    yield 'Isolated::recvMessage(const IPCMessage &data)\n{\n\tsize_t dataSize = data.data().size();\n\t'
    yield str((undefined(name='cmd_event_enum_name') if l_0_cmd_event_enum_name is missing else l_0_cmd_event_enum_name))
    yield ' _cmd = static_cast<'
    yield str((undefined(name='cmd_event_enum_name') if l_0_cmd_event_enum_name is missing else l_0_cmd_event_enum_name))
    yield '>(data.header().cmd);\n\n\tswitch (_cmd) {'
    for l_1_method in environment.getattr((undefined(name='interface_event') if l_0_interface_event is missing else l_0_interface_event), 'methods'):
        _loop_vars = {}
        pass
        yield '\n\tcase '
        yield str((undefined(name='cmd_event_enum_name') if l_0_cmd_event_enum_name is missing else l_0_cmd_event_enum_name))
        yield '::'
        yield str(t_2(environment.getattr(l_1_method, 'mojom_name')))
        yield ': {\n\t\t'
        yield str(environment.getattr(l_1_method, 'mojom_name'))
        yield 'Handler(data.data().cbegin(), dataSize, data.fds());\n\t\tbreak;\n\t}'
    l_1_method = missing
    yield '\n\tdefault:\n\t\tLOG(IPAProxy, Error) << "Unknown command " << static_cast<uint32_t>(_cmd);\n\t}\n}\n\n'
    for l_1_method in environment.getattr((undefined(name='interface_event') if l_0_interface_event is missing else l_0_interface_event), 'methods'):
        _loop_vars = {}
        pass
        yield '\nvoid '
        yield str((undefined(name='proxy_name') if l_0_proxy_name is missing else l_0_proxy_name))
        yield 'Isolated::'
        yield str(environment.getattr(l_1_method, 'mojom_name'))
        yield 'Handler(\n\t[[maybe_unused]] std::vector<uint8_t>::const_iterator data,\n\t[[maybe_unused]] size_t dataSize,\n\t[[maybe_unused]] const std::vector<SharedFD> &fds)\n{\n'
        yield str(context.call(environment.getattr((undefined(name='proxy_funcs') if l_0_proxy_funcs is missing else l_0_proxy_funcs), 'deserialize_call'), environment.getattr(l_1_method, 'parameters'), 'data', 'fds', False, True, True, 'dataSize', _loop_vars=_loop_vars))
        yield '\n\t'
        yield str(environment.getattr(l_1_method, 'mojom_name'))
        yield '.emit('
        yield str(t_10(environment.getattr(l_1_method, 'parameters')))
        yield ');\n}\n'
    l_1_method = missing
    if (undefined(name='has_namespace') if l_0_has_namespace is missing else l_0_has_namespace):
        pass
        yield '\n'
        for l_1_ns in t_11((undefined(name='namespace') if l_0_namespace is missing else l_0_namespace)):
            _loop_vars = {}
            pass
            yield '\n} /* namespace '
            yield str(l_1_ns)
            yield ' */\n'
        l_1_ns = missing
    yield '\n} /* namespace libcamera */'

blocks = {}
debug_info = '5=87&11=90&16=92&23=94&24=96&42=98&43=101&44=105&48=109&49=113&52=117&65=119&68=123&69=127&75=135&77=140&78=144&80=146&81=149&82=150&83=153&84=155&85=158&86=161&92=165&93=167&98=170&99=172&100=175&103=179&104=182&105=185&106=188&109=192&111=195&112=197&113=201&120=207&121=211&124=213&130=219&131=223&135=225&138=227&151=229&157=231&161=235&167=237&168=242&170=244&173=247&174=249&175=252&177=254&181=258&183=260&187=266&191=269&192=271&193=274&198=280&199=283&201=287&205=289&206=292&212=297&215=299&218=303&219=307&220=311&229=315&230=319&235=323&236=325&240=330&241=333&242=337'