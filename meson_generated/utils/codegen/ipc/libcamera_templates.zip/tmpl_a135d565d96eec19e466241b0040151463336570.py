from jinja2.runtime import LoopContext, Macro, Markup, Namespace, TemplateNotFound, TemplateReference, TemplateRuntimeError, Undefined, escape, identity, internalcode, markup_join, missing, str_join
name = 'proxy_functions.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    concat = environment.concat
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_func_sig = l_0_stop_thread_body = l_0_serialize_call = l_0_deserialize_param = l_0_deserialize_call = missing
    try:
        t_1 = environment.filters['has_fd']
    except KeyError:
        @internalcode
        def t_1(*unused):
            raise TemplateRuntimeError("No filter named 'has_fd' found.")
    try:
        t_2 = environment.filters['indent']
    except KeyError:
        @internalcode
        def t_2(*unused):
            raise TemplateRuntimeError("No filter named 'indent' found.")
    try:
        t_3 = environment.filters['length']
    except KeyError:
        @internalcode
        def t_3(*unused):
            raise TemplateRuntimeError("No filter named 'length' found.")
    try:
        t_4 = environment.filters['method_parameters']
    except KeyError:
        @internalcode
        def t_4(*unused):
            raise TemplateRuntimeError("No filter named 'method_parameters' found.")
    try:
        t_5 = environment.filters['method_return_value']
    except KeyError:
        @internalcode
        def t_5(*unused):
            raise TemplateRuntimeError("No filter named 'method_return_value' found.")
    try:
        t_6 = environment.filters['name']
    except KeyError:
        @internalcode
        def t_6(*unused):
            raise TemplateRuntimeError("No filter named 'name' found.")
    try:
        t_7 = environment.filters['name_full']
    except KeyError:
        @internalcode
        def t_7(*unused):
            raise TemplateRuntimeError("No filter named 'name_full' found.")
    try:
        t_8 = environment.filters['needs_control_serializer']
    except KeyError:
        @internalcode
        def t_8(*unused):
            raise TemplateRuntimeError("No filter named 'needs_control_serializer' found.")
    try:
        t_9 = environment.filters['with_fds']
    except KeyError:
        @internalcode
        def t_9(*unused):
            raise TemplateRuntimeError("No filter named 'with_fds' found.")
    pass
    def macro(l_1_class, l_1_method, l_1_suffix, l_1_need_class_name, l_1_override):
        t_10 = []
        if l_1_class is missing:
            l_1_class = undefined("parameter 'class' was not provided", name='class')
        if l_1_method is missing:
            l_1_method = undefined("parameter 'method' was not provided", name='method')
        if l_1_suffix is missing:
            l_1_suffix = ''
        if l_1_need_class_name is missing:
            l_1_need_class_name = True
        if l_1_override is missing:
            l_1_override = False
        pass
        t_10.extend((
            str(t_5(l_1_method)),
            ' ',
            str(((l_1_class + '::') if l_1_need_class_name else cond_expr_undefined("the inline if-expression on line 15 in 'proxy_functions.tmpl' evaluated to false and no else section was defined."))),
            str(environment.getattr(l_1_method, 'mojom_name')),
            str(l_1_suffix),
            '(',
        ))
        l_2_loop = missing
        for l_2_param, l_2_loop in LoopContext(t_4(l_1_method), undefined):
            _loop_vars = {}
            pass
            t_10.extend((
                '\n\t',
                str(l_2_param),
                str((',' if (not environment.getattr(l_2_loop, 'last')) else cond_expr_undefined("the inline if-expression on line 17 in 'proxy_functions.tmpl' evaluated to false and no else section was defined."))),
            ))
        l_2_loop = l_2_param = missing
        t_10.extend((
            ')',
            str((' override' if l_1_override else cond_expr_undefined("the inline if-expression on line 19 in 'proxy_functions.tmpl' evaluated to false and no else section was defined."))),
        ))
        return concat(t_10)
    context.exported_vars.add('func_sig')
    context.vars['func_sig'] = l_0_func_sig = Macro(environment, macro, 'func_sig', ('class', 'method', 'suffix', 'need_class_name', 'override'), False, False, False, context.eval_ctx.autoescape)
    def macro():
        t_11 = []
        pass
        t_11.append(
            'ASSERT(state_ != ProxyStopping);\n\tif (state_ != ProxyRunning)\n\t\treturn;\n\n\tstate_ = ProxyStopping;\n\n\tproxy_.invokeMethod(&ThreadProxy::stop, ConnectionTypeBlocking);\n\n\tthread_.exit();\n\tthread_.wait();\n\n\tThread::current()->dispatchMessages(Message::Type::InvokeMessage, this);\n\n\tstate_ = ProxyStopped;',
        )
        return concat(t_11)
    context.exported_vars.add('stop_thread_body')
    context.vars['stop_thread_body'] = l_0_stop_thread_body = Macro(environment, macro, 'stop_thread_body', (), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_params, l_1_buf, l_1_fds):
        t_12 = []
        if l_1_params is missing:
            l_1_params = undefined("parameter 'params' was not provided", name='params')
        if l_1_buf is missing:
            l_1_buf = undefined("parameter 'buf' was not provided", name='buf')
        if l_1_fds is missing:
            l_1_fds = undefined("parameter 'fds' was not provided", name='fds')
        pass
        for l_2_param in l_1_params:
            _loop_vars = {}
            pass
            t_12.extend((
                '\n\tstd::vector<uint8_t> ',
                str(environment.getattr(l_2_param, 'mojom_name')),
                'Buf;',
            ))
            if t_1(l_2_param):
                pass
                t_12.extend((
                    '\n\tstd::vector<SharedFD> ',
                    str(environment.getattr(l_2_param, 'mojom_name')),
                    'Fds;\n\tstd::tie(',
                    str(environment.getattr(l_2_param, 'mojom_name')),
                    'Buf, ',
                    str(environment.getattr(l_2_param, 'mojom_name')),
                    'Fds) =',
                ))
            else:
                pass
                t_12.extend((
                    '\n\tstd::tie(',
                    str(environment.getattr(l_2_param, 'mojom_name')),
                    'Buf, std::ignore) =',
                ))
            t_12.extend((
                '\n\t\tIPADataSerializer<',
                str(t_7(l_2_param)),
                '>::serialize(',
                str(environment.getattr(l_2_param, 'mojom_name')),
                str((', &controlSerializer_' if t_8(l_2_param) else cond_expr_undefined("the inline if-expression on line 63 in 'proxy_functions.tmpl' evaluated to false and no else section was defined."))),
                ');',
            ))
        l_2_param = missing
        if (t_3(l_1_params) > 1):
            pass
            for l_2_param in l_1_params:
                _loop_vars = {}
                pass
                t_12.extend((
                    '\n\tappendPOD<uint32_t>(',
                    str(l_1_buf),
                    ', ',
                    str(environment.getattr(l_2_param, 'mojom_name')),
                    'Buf.size());',
                ))
                if t_1(l_2_param):
                    pass
                    t_12.extend((
                        '\n\tappendPOD<uint32_t>(',
                        str(l_1_buf),
                        ', ',
                        str(environment.getattr(l_2_param, 'mojom_name')),
                        'Fds.size());',
                    ))
            l_2_param = missing
        for l_2_param in l_1_params:
            _loop_vars = {}
            pass
            t_12.extend((
                '\n\t',
                str(l_1_buf),
                '.insert(',
                str(l_1_buf),
                '.end(), ',
                str(environment.getattr(l_2_param, 'mojom_name')),
                'Buf.begin(), ',
                str(environment.getattr(l_2_param, 'mojom_name')),
                'Buf.end());',
            ))
        l_2_param = missing
        for l_2_param in l_1_params:
            _loop_vars = {}
            pass
            if t_1(l_2_param):
                pass
                t_12.extend((
                    '\n\t',
                    str(l_1_fds),
                    '.insert(',
                    str(l_1_fds),
                    '.end(), ',
                    str(environment.getattr(l_2_param, 'mojom_name')),
                    'Fds.begin(), ',
                    str(environment.getattr(l_2_param, 'mojom_name')),
                    'Fds.end());',
                ))
        l_2_param = missing
        return concat(t_12)
    context.exported_vars.add('serialize_call')
    context.vars['serialize_call'] = l_0_serialize_call = Macro(environment, macro, 'serialize_call', ('params', 'buf', 'fds'), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_param, l_1_pointer, l_1_loop, l_1_buf, l_1_fds, l_1_iter, l_1_data_size):
        t_13 = []
        if l_1_param is missing:
            l_1_param = undefined("parameter 'param' was not provided", name='param')
        if l_1_pointer is missing:
            l_1_pointer = undefined("parameter 'pointer' was not provided", name='pointer')
        if l_1_loop is missing:
            l_1_loop = undefined("parameter 'loop' was not provided", name='loop')
        if l_1_buf is missing:
            l_1_buf = undefined("parameter 'buf' was not provided", name='buf')
        if l_1_fds is missing:
            l_1_fds = undefined("parameter 'fds' was not provided", name='fds')
        if l_1_iter is missing:
            l_1_iter = undefined("parameter 'iter' was not provided", name='iter')
        if l_1_data_size is missing:
            l_1_data_size = undefined("parameter 'data_size' was not provided", name='data_size')
        pass
        t_13.extend((
            str(('*' if l_1_pointer else cond_expr_undefined("the inline if-expression on line 100 in 'proxy_functions.tmpl' evaluated to false and no else section was defined."))),
            str(environment.getattr(l_1_param, 'mojom_name')),
            ' =\nIPADataSerializer<',
            str(t_7(l_1_param)),
            '>::deserialize(\n\t',
            str(l_1_buf),
            str(('.cbegin()' if (not l_1_iter) else cond_expr_undefined("the inline if-expression on line 102 in 'proxy_functions.tmpl' evaluated to false and no else section was defined."))),
            ' + ',
            str(environment.getattr(l_1_param, 'mojom_name')),
            'Start,',
        ))
        if (environment.getattr(l_1_loop, 'last') and (not l_1_iter)):
            pass
            t_13.extend((
                '\n\t',
                str(l_1_buf),
                '.cend()',
            ))
        elif (not l_1_iter):
            pass
            t_13.extend((
                '\n\t',
                str(l_1_buf),
                '.cbegin() + ',
                str(environment.getattr(l_1_param, 'mojom_name')),
                'Start + ',
                str(environment.getattr(l_1_param, 'mojom_name')),
                'BufSize',
            ))
        elif (l_1_iter and (environment.getattr(l_1_loop, 'length') == 1)):
            pass
            t_13.extend((
                '\n\t',
                str(l_1_buf),
                ' + ',
                str(l_1_data_size),
            ))
        else:
            pass
            t_13.extend((
                '\n\t',
                str(l_1_buf),
                ' + ',
                str(environment.getattr(l_1_param, 'mojom_name')),
                'Start + ',
                str(environment.getattr(l_1_param, 'mojom_name')),
                'BufSize',
            ))
        t_13.append(
            str((',' if t_1(l_1_param) else cond_expr_undefined("the inline if-expression on line 112 in 'proxy_functions.tmpl' evaluated to false and no else section was defined."))),
        )
        if t_1(l_1_param):
            pass
            t_13.extend((
                '\n\t',
                str(l_1_fds),
                '.cbegin() + ',
                str(environment.getattr(l_1_param, 'mojom_name')),
                'FdStart,',
            ))
            if environment.getattr(l_1_loop, 'last'):
                pass
                t_13.extend((
                    '\n\t',
                    str(l_1_fds),
                    '.cend()',
                ))
            else:
                pass
                t_13.extend((
                    '\n\t',
                    str(l_1_fds),
                    '.cbegin() + ',
                    str(environment.getattr(l_1_param, 'mojom_name')),
                    'FdStart + ',
                    str(environment.getattr(l_1_param, 'mojom_name')),
                    'FdsSize',
                ))
        t_13.append(
            str((',' if t_8(l_1_param) else cond_expr_undefined("the inline if-expression on line 121 in 'proxy_functions.tmpl' evaluated to false and no else section was defined."))),
        )
        if t_8(l_1_param):
            pass
            t_13.append(
                '\n\t&controlSerializer_',
            )
        t_13.append(
            ');',
        )
        return concat(t_13)
    context.exported_vars.add('deserialize_param')
    context.vars['deserialize_param'] = l_0_deserialize_param = Macro(environment, macro, 'deserialize_param', ('param', 'pointer', 'loop', 'buf', 'fds', 'iter', 'data_size'), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_params, l_1_buf, l_1_fds, l_1_pointer, l_1_declare, l_1_iter, l_1_data_size, l_1_init_offset):
        t_14 = []
        l_1_namespace = resolve('namespace')
        l_1_ns = missing
        if l_1_params is missing:
            l_1_params = undefined("parameter 'params' was not provided", name='params')
        if l_1_buf is missing:
            l_1_buf = undefined("parameter 'buf' was not provided", name='buf')
        if l_1_fds is missing:
            l_1_fds = undefined("parameter 'fds' was not provided", name='fds')
        if l_1_pointer is missing:
            l_1_pointer = True
        if l_1_declare is missing:
            l_1_declare = False
        if l_1_iter is missing:
            l_1_iter = False
        if l_1_data_size is missing:
            l_1_data_size = ''
        if l_1_init_offset is missing:
            l_1_init_offset = 0
        pass
        l_1_ns = context.call((undefined(name='namespace') if l_1_namespace is missing else l_1_namespace), size_offset=l_1_init_offset)
        if (t_3(l_1_params) > 1):
            pass
            for l_2_param in l_1_params:
                _loop_vars = {}
                pass
                t_14.extend((
                    '\n\t[[maybe_unused]] const size_t ',
                    str(environment.getattr(l_2_param, 'mojom_name')),
                    'BufSize = readPOD<uint32_t>(',
                    str(l_1_buf),
                    ', ',
                    str(environment.getattr((undefined(name='ns') if l_1_ns is missing else l_1_ns), 'size_offset')),
                ))
                if l_1_iter:
                    pass
                    t_14.extend((
                        ', ',
                        str(l_1_buf),
                        ' + ',
                        str(l_1_data_size),
                    ))
                t_14.append(
                    ');',
                )
                if not isinstance(l_1_ns, Namespace):
                    raise TemplateRuntimeError("cannot assign attribute on non-namespace object")
                l_1_ns['size_offset'] = (environment.getattr((undefined(name='ns') if l_1_ns is missing else l_1_ns), 'size_offset') + 4)
                if t_1(l_2_param):
                    pass
                    t_14.extend((
                        '\n\t[[maybe_unused]] const size_t ',
                        str(environment.getattr(l_2_param, 'mojom_name')),
                        'FdsSize = readPOD<uint32_t>(',
                        str(l_1_buf),
                        ', ',
                        str(environment.getattr((undefined(name='ns') if l_1_ns is missing else l_1_ns), 'size_offset')),
                    ))
                    if l_1_iter:
                        pass
                        t_14.extend((
                            ', ',
                            str(l_1_buf),
                            ' + ',
                            str(l_1_data_size),
                        ))
                    t_14.append(
                        ');',
                    )
                    if not isinstance(l_1_ns, Namespace):
                        raise TemplateRuntimeError("cannot assign attribute on non-namespace object")
                    l_1_ns['size_offset'] = (environment.getattr((undefined(name='ns') if l_1_ns is missing else l_1_ns), 'size_offset') + 4)
            l_2_param = missing
        t_14.append(
            '\n',
        )
        l_2_loop = missing
        for l_2_param, l_2_loop in LoopContext(l_1_params, undefined):
            _loop_vars = {}
            pass
            if environment.getattr(l_2_loop, 'first'):
                pass
                t_14.extend((
                    '\n\tconst size_t ',
                    str(environment.getattr(l_2_param, 'mojom_name')),
                    'Start = ',
                    str(environment.getattr((undefined(name='ns') if l_1_ns is missing else l_1_ns), 'size_offset')),
                    ';',
                ))
            else:
                pass
                t_14.extend((
                    '\n\tconst size_t ',
                    str(environment.getattr(l_2_param, 'mojom_name')),
                    'Start = ',
                    str(environment.getattr(environment.getattr(l_2_loop, 'previtem'), 'mojom_name')),
                    'Start + ',
                    str(environment.getattr(environment.getattr(l_2_loop, 'previtem'), 'mojom_name')),
                    'BufSize;',
                ))
        l_2_loop = l_2_param = missing
        t_14.append(
            '\n',
        )
        l_2_loop = missing
        for l_2_param, l_2_loop in LoopContext(t_9(l_1_params), undefined):
            _loop_vars = {}
            pass
            if environment.getattr(l_2_loop, 'first'):
                pass
                t_14.extend((
                    '\n\tconst size_t ',
                    str(environment.getattr(l_2_param, 'mojom_name')),
                    'FdStart = 0;',
                ))
            else:
                pass
                t_14.extend((
                    '\n\tconst size_t ',
                    str(environment.getattr(l_2_param, 'mojom_name')),
                    'FdStart = ',
                    str(environment.getattr(environment.getattr(l_2_loop, 'previtem'), 'mojom_name')),
                    'FdStart + ',
                    str(environment.getattr(environment.getattr(l_2_loop, 'previtem'), 'mojom_name')),
                    'FdsSize;',
                ))
        l_2_loop = l_2_param = missing
        t_14.append(
            '\n',
        )
        l_2_loop = missing
        for l_2_param, l_2_loop in LoopContext(l_1_params, undefined):
            _loop_vars = {}
            pass
            if l_1_pointer:
                pass
                t_14.extend((
                    '\n\tif (',
                    str(environment.getattr(l_2_param, 'mojom_name')),
                    ') {\n',
                    str(t_2(context.call((undefined(name='deserialize_param') if l_0_deserialize_param is missing else l_0_deserialize_param), l_2_param, l_1_pointer, l_2_loop, l_1_buf, l_1_fds, l_1_iter, l_1_data_size, _loop_vars=_loop_vars), 16, True)),
                    '\n\t}',
                ))
            else:
                pass
                t_14.extend((
                    '\n\t',
                    str(((t_6(l_2_param) + ' ') if l_1_declare else cond_expr_undefined("the inline if-expression on line 184 in 'proxy_functions.tmpl' evaluated to false and no else section was defined."))),
                    str(t_2(context.call((undefined(name='deserialize_param') if l_0_deserialize_param is missing else l_0_deserialize_param), l_2_param, l_1_pointer, l_2_loop, l_1_buf, l_1_fds, l_1_iter, l_1_data_size, _loop_vars=_loop_vars), 8)),
                ))
            t_14.append(
                '\n',
            )
        l_2_loop = l_2_param = missing
        return concat(t_14)
    context.exported_vars.add('deserialize_call')
    context.vars['deserialize_call'] = l_0_deserialize_call = Macro(environment, macro, 'deserialize_call', ('params', 'buf', 'fds', 'pointer', 'declare', 'iter', 'data_size', 'init_offset'), False, False, False, context.eval_ctx.autoescape)

blocks = {}
debug_info = '14=66&15=80&16=88&17=93&19=99&25=104&53=113&54=122&55=127&56=130&57=134&58=136&60=145&62=150&63=153&67=157&68=159&69=164&70=169&71=173&76=179&77=184&80=194&81=197&82=201&99=214&100=232&101=235&102=237&103=243&104=247&105=250&106=254&107=261&108=265&110=273&112=281&113=283&114=287&115=292&116=296&118=303&121=311&122=313&144=324&145=345&146=346&147=348&148=353&149=359&150=363&153=370&154=373&155=377&156=383&157=387&160=394&164=402&165=405&166=409&168=418&171=430&172=433&173=437&175=444&178=456&179=459&180=463&181=465&184=472'